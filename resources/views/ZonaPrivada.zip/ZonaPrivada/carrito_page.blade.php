<?php
$email = Auth::guard('cliente')->user()->email;
$id = Auth::guard('cliente')->user()->id;
$username = Auth::guard('cliente')->user()->username;
?>
<style>
    .filtro_banner:before {
        content: "";
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 45px;
        background: #1F3041;
        width: 100%;
        height: 100%;
        opacity: 0.6;
        top: 0;
        position: absolute;
    }

    td {
        border-top: 1px solid #ddd !important;
        border-bottom: 1px solid #ddd !important;
    }

    .box {
        width: 100%;
        padding: 2em;
        text-align: center;
    }

    .quantity {
        position: relative;
        display: inline-block;
        color: #7f7f7f;
    }

    input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield;
    }

    .quantity input[type="number"] {
        transition: border 0.3s ease-in-out, color 0.3s ease-in-out;
        -webkit-appearance: textfield;
        -moz-appearance: textfield;
        appearance: textfield;
        font-family: Arial, sans-serif;
        font-size: 14px;
        line-height: 24px;
        font-weight: 700;
        box-shadow: none;
        outline: none;
        width: 85px;
        height: 40px;
        text-align: center;
        float: right;
        border: 1px solid #dcdcdc;
        background-color: #fff;
        color: #342f2f;
    }

    .quantity input[type="number"]:focus {
        border-color: #57b8f6 !important;
    }

    .quantity input[type="number"]:hover {
        border-color: #a5a5a5;
    }

    .quantity-button {
        width: 39px;
        height: 34px;
        display: inline-block;
        float: right;
        position: relative;
        cursor: pointer;
    }

    .quantity-button::before,
    .quantity-button::after {
        position: absolute;
        top: calc(50% - 1px);
        left: calc(50% - 7px);
        content: '';
        width: 14px;
        height: 2px;
        background-color: currentColor;
        display: block;
    }

    .quantity-remove::after {
        display: none;
    }

    .quantity-add::after {
        transform: rotate(90deg);
    }
</style>

<form method="POST" id="formCarrito" enctype="multipart/form-data">
    @csrf
    <div class="d-flex flex-column justify-content-center align-items-center col-12 producto_container mt-4 px-5">
        <div class="col-12 d-flex justify-content-between align-items-center flex-wrap flex-row my-2">
            <div class="text-start" style="font-size:32px;color:#0E7D4A;">CARRITO</div>
        </div>
    </div>
    <div
        class="col-12 px-4 d-flex flex-column flex-md-row justify-content-between align-items-start container-fluid  px-5">
        <div class="col-md-6 box-carrito d-flex flex-column">
        </div>

        <div class="col-12 col-md-6 d-flex flex-column ps-0 ps-md-4">
            <div style="border-bottom:1px solid #ddd;">
                <div class="w-100 d-flex justify-content-between p-2">
                    <span style="font-weight:bold">Subtotal</span><span style="font-weight:bold" id="subtotal"></span>
                </div>
            </div>
            <div class="py-4">
                * Una vez que confirmemos el stock de los productos se te enviara un mail con la factura para proceder a
                hacer el pago.
            </div>
            <br>
            <div>
                Cuando realice el pago recuerde informarlo enviándonos un comprobante. Puede informar el pago por
                WhatsApp al 54 11 48895965

            </div>
        </div>
    </div>

    <div class="d-flex flex-row justify-content-between mb-4 mt-4 px-5">
        <button
            style="border:1px solid #0E7D4A;color:#0E7D4A;font-size:13px;font-weight: bold;width: 163px;border-radius:35px;width:216px;"
            onclick="window.location='{{ route('page.productosCategorias') }}'" class="btn me-4"
            type="button"><b>Volver</b></button>
        <button type="button" onclick="enviar()" class="btn  px-md-3 rounded-pill"
            style="width: 168px;border-radius: 35px!important;background-color: #0E7D4A;color:white;width:216px;font-weight: bold;">
            Siguiente paso
        </button>
    </div>
</form>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
    integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"
    integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<!--Alertify-->
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script>
    ///ENVIO AJAX    
    function enviar() {
        let filaTabla = document.querySelectorAll(".tablaFila");
        let producto = new Array();
        filaTabla.forEach(element => {
            const fila = {
                imagen: element.querySelector('#imagen').src,
                codigo: element.querySelector('.pcodigo').value,
                cantidad: element.querySelector('.filaCantidad').value,
                nombre: element.querySelector('.filaNombre').textContent,
                precio: element.querySelector('.filaPrecio').value,
                subtotal: element.querySelector('#cantidadPrecio').textContent,
            };
            producto.push(fila);
        });
        producto = JSON.stringify(producto);
        sessionStorage.setItem('carrito', producto);     
        window.location.assign('/_euma/carrito-2')

    };

    function removeItemFromArr(arr, item) {
        var i = arr.indexOf(item);
        arr.splice(i, 1);
    }


    function tabla() {
        tabla = $('.box-carrito');
        var template = '';
        obj_fila = sessionStorage.getItem('obj_fila');
        subtotal = 0;
        if (obj_fila != null) {
            obj_fila = jQuery.parseJSON(obj_fila);
            obj_fila = $.makeArray(obj_fila);
            total = 0;

            for (i = 0; i < obj_fila.length; i++) {
                template +=
                    `<div class="tablaFila card mb-3 d-flex flex-row" id="fila_${i}" data-presentacion="${obj_fila[i]['presentacion']}" data-codigo="${obj_fila[i]['codigo']}" style="border-bottom:1px solid #ccc;">`
                template += `<input type="hidden" class="pcodigo" name="codigo[]" value="${obj_fila[i]['codigo']}">`
                template += `<input type="hidden" name="nombre[]" value="${obj_fila[i]['nombre']}">`
                template += `<input type="hidden" name="cantidad[]" value="${obj_fila[i]['cantidad']}">`
                template += `<input type="hidden" class="filaPrecio" name="precio[]" value="${obj_fila[i]['precio']}">`
                template +=
                    `<input type="hidden" class="filaProductoId" name="filaProductoId[]" value="${obj_fila[i]['productoid']}">`

                template += `<div  class="pt-2 pb-2 col-3 d-flex justify-content-center align-items-cent" style="font-size: 16px;font-weight:bold;text-transform:uppercase;color:#707070;">
                        <img id="imagen" src="{{ asset('images/logoProd.png') }}" width="77px" height="auto">
                        </div>`
                template += `<div  class="col-6 d-flex flex-column mx-2">`
                template += `<div  class="filaCodigo"></div>`
                template +=
                    `<div  class="pt-2 pb-2 filaNombre" style="font-size: 16px;font-weight:bold;text-transform:uppercase;color:#707070;">${obj_fila[i]['nombre']}</div>`
                //             template +=
                //                 `<div class="pt-2 pb-2" style="font-size: 16px;font-weight:bold;text-transform:uppercase;color:#707070;"><input style="width: 27%;
                // text-align: center;" type="number" data-unidad="${obj_fila[i]['unidad']}" data-precio="${obj_fila[i]['precio']}" data-fila="${i}" value="${obj_fila[i]['cantidad']}" min="${obj_fila[i]['unidad']}" step="${obj_fila[i]['unidad']}" class="form-control filaCantidad"></div>`
                template +=
                    `<div class="pt-2 pb-2" style="font-size: 16px;font-weight:bold;text-transform:uppercase;color:#707070;">
                        <div>
                                                            <div class="quantity">
                                                                <span class="quantity-add quantity-button"></span>
                                                                <input type="number" 
                                                                data-cantidad="${obj_fila[i]['unidad']}" 
                                                                data-unidad="${obj_fila[i]['unidad']}" 
                                                                data-precio="${obj_fila[i]['precio']}" 
                                                                data-fila="${i}" value="${obj_fila[i]['cantidad']}" 
                                                                min="${obj_fila[i]['unidad']}" 
                                                                step="${obj_fila[i]['unidad']}" 
                                                                class="form-control filaCantidad
                                                                id="cantidad">
                                                                <span class="quantity-remove quantity-button"></span>
                                                            </div>
                                                        </div>                        
                    </div>`
                template += "</div>"
                template += `<div  class="col-3 d-flex flex-row justify-content-center">`
                template +=
                    `<div class="pt-2 pb-2 subtotal${i} d-flex justify-content-center align-items-center" style="font-size: 16px;font-weight:bold;text-transform:uppercase;color:#707070;" id="cantidadPrecio" data-precio="${obj_fila[i]['precio']}">$ ${obj_fila[i]['subtotal']}</div>`
                template +=
                    `<div class="pt-2 pb-2 d-flex justify-content-center align-items-center" style="font-size: 16px;font-weight:bold;text-transform:uppercase;color:#707070;"><buttom type="buttom" onclick="eliminar('fila_${i}')" class="btn"><img src="{{ asset('images/delete_logo.png') }}"></buttom></td>`
                template += "</div>"

                template += `</div>`
                template += '</div>'

                precio = parseFloat(obj_fila[i]['precio']);
                cantidad = parseInt(obj_fila[i]['cantidad']);
                subtotal = parseInt(obj_fila[i]['subtotal']);
                //subtotal = precio*cantidad;
                total += subtotal;
            }
            total = total.toFixed(2)
            $('#subtotal').html("$ " + total)
            $('#total').html("$ " + total)
            tabla.append(template)

            $('#totalhidden').val("$ " + total)

        } else {

        }

    }
    document.onload = tabla();

    function eliminar(id) {
        var codigo = $('#' + id).data('codigo')
        var nombre = $('#' + id).data('nombre')

        obj_fila = sessionStorage.getItem('obj_fila');

        obj_fila = jQuery.parseJSON(obj_fila);
        obj_fila = $.makeArray(obj_fila);

        obj_fila.forEach(function(element) {
            if (element['codigo'] == codigo) {
                removeItemFromArr(obj_fila, element)
            }
        })

        sessionStorage.setItem('obj_fila', JSON.stringify(obj_fila));

        $('#' + id).remove();
        location.reload();
    }
    ///FUNCION ESCUCHAR CANTIDAD
    $(document).on('keyup mouseup', '.filaCantidad', function() {

        let id = $(this).data('fila')
        let unidad = $(this).data('unidad')
        let cantidad = $(this).val();
        let precio = $(this).data('precio')
        let total = parseFloat(precio) * (cantidad / parseInt(unidad))

        $(`.subtotal${id}`).html("$ " + total.toFixed(2))

        $(`.filaSubtotal${id}`).value = total.toFixed(2);
        let totalPedido = 0;
        let filaTabla = document.querySelectorAll(".tablaFila");
        console.log(filaTabla)
        let producto = new Array();
        filaTabla.forEach(element => {
            cantidad = element.querySelector('.filaCantidad').value;
            unudad = element.querySelector('.filaCantidad').dataset.unidad;
            cantidad = parseInt(cantidad) / parseInt(unidad);
            precio = element.querySelector('.filaPrecio').value;
            subtotal = parseInt(cantidad) * parseFloat(precio);
            subtotal = subtotal.toFixed(2);
            console.log(parseFloat(subtotal).toFixed(2))
            totalPedido = parseFloat(subtotal) + parseFloat(totalPedido);
        });
        console.log("a")
        $('#subtotal').html("$ " + totalPedido.toFixed(2))
    });

    $('.quantity-button').off('click').on('click', function() {

        let cantidadAux = parseInt($(this).parent().find('input').data('cantidad'));
        console.log($(this).parent().find('input'))
        if ($(this).hasClass('quantity-add')) {
            var addValue = parseInt($(this).parent().find('input').val()) + cantidadAux;
            $(this).parent().find('input').val(addValue).trigger('change');
        }

        if ($(this).hasClass('quantity-remove')) {
            var removeValue = parseInt($(this).parent().find('input').val()) - cantidadAux;
            if (removeValue == 0) {
                removeValue = 1;
            }
            $(this).parent().find('input').val(removeValue).trigger('change');
        }

        let id = $(this).parent().find('input').data('fila')
        let unidad = $(this).parent().find('input').data('unidad')
        let cantidad = parseInt($(this).parent().find('input').val())
        let precio = $(this).parent().find('input').data('precio')
        let total = parseFloat(precio) * (cantidad / parseInt(unidad))

        $(`.subtotal${id}`).html("$ " + total.toFixed(2))

        $(`.filaSubtotal${id}`).value = total.toFixed(2);
        let totalPedido = 0;
        let filaTabla = document.querySelectorAll(".tablaFila");
        console.log(filaTabla)
        let producto = new Array();
        filaTabla.forEach(element => {
            cantidad = element.querySelector('.filaCantidad').value;
            unudad = element.querySelector('.filaCantidad').dataset.unidad;
            cantidad = parseInt(cantidad) / parseInt(unidad);
            precio = element.querySelector('.filaPrecio').value;
            subtotal = parseInt(cantidad) * parseFloat(precio);
            subtotal = subtotal.toFixed(2);
            console.log(parseFloat(subtotal).toFixed(2))
            totalPedido = parseFloat(subtotal) + parseFloat(totalPedido);
        });

        $('#subtotal').html("$ " + totalPedido.toFixed(2))
    });
</script>
